'use strict'
const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/alm', {useMongoClient: true})
    .then(() => {
        console.log('La conexión a MongoDB se ha realizado correctamente!!');
    }).catch(err => console.log(err));
///terminp
///construccion del esquema de la base de datos
const datosSchema = new mongoose.Schema({
    nombre: String,
    apellido: String
});
///},{collection:'datos'});



const Datos = mongoose.model("Datos", datosSchema);
/////

const express = require('express');


const path = require('path');
const app = express();
const cors = require('cors');


const port = 3300;
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const server = require('http').createServer( app );
const pollsRouter = require( './api/routers/polls-router.js' );


//body parser
app.use(bodyParser.urlencoded( {extended: true} ) );
app.use(bodyParser.json());

app.use("/datos", pollsRouter);


// Add headers
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.header('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.header('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.header('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});


server.listen( port,"0.0.0.0", () =>{
    console.log( "Servidor ejecutandose en puerto:", port );
} );
pollsRouter.post('/', ( request, response) => {
    const myData = new Datos(request.body);
    myData.save().then(item => {
        response.json(myData);
    })
});


//http://localhost:3300/all
app.get('/all', function(req, res, next)
{
    Datos.find(function( err, datos, count )
    {
        res.send(datos);
    });
});
const pollsRouter = require( 'express' ).Router();
const polls = {
    nombre: 'Fanny',
    apellido: 'Fanny'
};

module.exports = pollsRouter;
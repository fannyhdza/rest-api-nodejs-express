const request = require('request');

function RealizarPost(){
    return new Promise(function (resolve, reject) {
        ////////////////////////
        request.post({
            headers: {
                'content-type': 'application/json'
            },
            url: 'http://localhost:3300/datos',
            body: JSON.stringify({"nombre":"f"})
        }, function (error, response, body) {
            console.log(body);
            return body;

        });
        /////////////////////
    });
}

async function runner() {
    const body = await RealizarPost();
    return body;
}

for (let i=0; i<15000; i++){
   //console.log(i,runner());
    runner().then(function (e) {

           console.log(e);
        }

    );
}
